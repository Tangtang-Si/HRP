import numpy as np
import torch
from sklearn import metrics
from tqdm import tqdm
from matplotlib import pyplot as plt
import torch.nn as nn
from torch.utils.data import DataLoader
from PIL import Image
import gc

def train(device,inputs: list,model,criterion,optimizer,dataloader,epoch):  #主模型需要传入epoch
# def train(device,inputs: list,model,criterion,optimizer,dataloader):
    model.train()
    model.to(device)
    prob_all = []
    label_all = []
    prob_auc = []
    loss_total = 0.0
    tqdm_batch_iterator = tqdm(dataloader)
    for batch_index, sample_batch in enumerate(tqdm_batch_iterator):
        gc.collect()
        inputs = {input: sample_batch[input].cuda(device) for input in inputs}
        # sample_batch = {k: v.to(device) for k, v in sample_batch.items()}
        label = sample_batch['label'].cuda(device)
        optimizer.zero_grad()
        outputs = model(inputs,epoch)
        # outputs = model(inputs)
        if type(outputs) == tuple: ###判断模型是否返回额外的loss计算结果
            output,extra_loss = outputs      #注意：output=evidence_a
            loss = criterion(output,label.long())
            # text, image, rt_ri, evidence_a, extra_loss = outputs
            # loss = criterion(evidence_a, label.long())
            loss += extra_loss
        else:
            output = outputs
            loss = criterion(output,label.long())
        loss.backward()
        optimizer.step()
        loss_total += loss.item()
        description = "loss: {:.4f}".format(loss_total / (batch_index + 1))
        tqdm_batch_iterator.set_description(description)
        prob = output.cpu().detach().numpy()  # 先把outputs转到CPU上，然后再转成numpy，如果本身在CPU上训练的话就不用先转成CPU了
        # prob = evidence_a.cpu().detach().numpy()
        prob_auc.extend(prob[:, 1])
        prob_all.extend(np.argmax(prob, axis=1))  # 求每一行的最大值索引
        for i in label:
            label_all.append(i.item())

    loss = loss_total / len(dataloader)
    accuracy = metrics.accuracy_score(label_all, prob_all)
    recall = metrics.recall_score(label_all, prob_all, average='macro')
    precision = metrics.precision_score(label_all, prob_all, average='macro')
    f1_score = metrics.f1_score(label_all, prob_all, average='macro')
    auc = metrics.roc_auc_score(label_all, prob_auc, multi_class='ovr')
    # print("train loss {0:.4f};Accuracy {1:.4f};F1_Score {2:.4f};auc{3:.4f}".format(loss, accuracy, f1_score, auc))
    return loss, accuracy, recall,precision,f1_score, auc

def test(device,inputs:list,model,criterion,dataloader,epoch):
# def test(device, inputs: list, model, criterion, dataloader):
    model.eval()
    model.to(device)
    loss_total = 0.0
    prob_all = []
    label_all = []
    prob_auc = []
    with torch.no_grad():
        for sample_batch in dataloader:
            inputs = {input: sample_batch[input].cuda(device) for input in inputs}
            # sample_batch = {k: v.to(device) for k, v in sample_batch.items()}
            label = sample_batch['label'].cuda(device)
            # evidence, evidence_a, loss = model(epoch,**sample_batch)
            outputs = model(inputs,epoch)
            # outputs = model(inputs)
            if type(outputs) == tuple:###判断模型是否返回额外的loss计算结果
                output,extra_loss = outputs
                loss = criterion(output,label.long())
                # text, image, rt_ri, evidence_a, extra_loss = outputs
                # loss = criterion(evidence_a, label.long())
                loss += extra_loss
            else:
                output = outputs
                loss = criterion(output,label.long())
            loss_total += loss.item()
            prob = output.cpu().detach().numpy()  # 先把outputs转到CPU上，然后再转成numpy，如果本身在CPU上训练的话就不用先转成CPU了
            # prob = evidence_a.cpu().detach().numpy()
            prob_auc.extend(prob[:, 1])
            prob_all.extend(np.argmax(prob, axis=1))  # 求每一行的最大值索引
            for i in label:
                label_all.append(i.item())


    loss = loss_total / len(dataloader)
    accuracy = metrics.accuracy_score(label_all, prob_all)
    recall = metrics.recall_score(label_all, prob_all, average='macro')
    precision = metrics.precision_score(label_all, prob_all, average='macro')
    f1_score = metrics.f1_score(label_all, prob_all, average='macro')
    auc = metrics.roc_auc_score(label_all, prob_auc, multi_class='ovr')
    # print("test loss {0:.4f};Accuracy {1:.4f};F1_Score;{2:.4f};auc{3:.4f}".format(loss, accuracy,  f1_score, auc))
    return loss, accuracy, recall,precision, f1_score, auc

# def dev(device,inputs:list,model,criterion,dataloader,epoch):
#     model.eval()
#     model.to(device)
#     loss_total = 0.0
#     prob_all = []
#     label_all = []
#     prob_auc = []
#     with torch.no_grad():
#         for sample_batch in dataloader:
#             inputs = {input: sample_batch[input].cuda(device) for input in inputs}
#             # sample_batch = {k: v.to(device) for k, v in sample_batch.items()}
#             label = sample_batch['label'].cuda(device)
#             # print(label)
#             # evidence, evidence_a, loss = model(epoch,**sample_batch)
#             outputs = model(inputs,epoch)
#             if type(outputs) == tuple:###判断模型是否返回额外的loss计算结果
#                 text, image, rt_ri,evidence_a,extra_loss = outputs
#                 loss = criterion(evidence_a,label.long())
#                 # output, extra_loss = outputs
#                 # loss = criterion(output, label.long())
#                 loss += extra_loss
#                 print(f'文本的分类结果:\n{text}')
#                 print('文本分类的不确定性u1:',2/(text[0][0]+text[0][1]+2),2/(text[1][0]+text[1][1]+2),2/(text[2][0]+text[2][1]+2))
#                 print(f'图片的分类结果:\n{image}')
#                 print('图片分类的不确定性u2:', 2/(image[0][0]+image[0][1]+2), 2/(image[1][0]+image[1][1]+2), 2/(image[2][0]+image[2][1]+2))
#                 print(f'图文的分类结果:\n{rt_ri}')
#                 print('图文分类的不确定性u3:', 2/(rt_ri[0][0]+rt_ri[0][1]+2), 2/(rt_ri[1][0]+rt_ri[1][1]+2), 2/(rt_ri[2][0]+rt_ri[2][1]+2))
#                 print(f'融合后的分类结果:\n{evidence_a}')
#                 print('融合后的不确定性u:',2/(evidence_a[0][0]+evidence_a[0][1]+2),2/(evidence_a[1][0]+evidence_a[1][1]+2),2/(evidence_a[2][0]+evidence_a[2][1]+2))
#             else:
#                 output = outputs
#                 loss = criterion(output,label.long())
#             loss_total += loss.item()
#             # prob = output.cpu().detach().numpy()  # 先把outputs转到CPU上，然后再转成numpy，如果本身在CPU上训练的话就不用先转成CPU了
#             prob = evidence_a.cpu().detach().numpy()
#             prob_auc.extend(prob[:, 1])
#             prob_all.extend(np.argmax(prob, axis=1))  # 求每一行的最大值索引
#             for i in label:
#                 label_all.append(i.item())
#
#     loss = loss_total / len(dataloader)
#     accuracy = metrics.accuracy_score(label_all, prob_all)
#     # recall = metrics.recall_score(label_all, prob_all, average='macro')
#     # precision = metrics.precision_score(label_all, prob_all, average='macro')
#     f1_score = metrics.f1_score(label_all, prob_all, average='macro')
#     # auc = metrics.roc_auc_score(label_all, prob_auc, multi_class='ovr')
#     auc=0
#     # print("dev loss {0:.4f};Accuracy {1:.4f};F1_Score;{2:.4f};auc{3:.4f}".format(loss, accuracy,  f1_score, auc))
#     return loss,accuracy,f1_score,auc

def pad_image(image, target_size):
    """
       图片大小的更改
       :param image: input image
       :param target_size: a tuple (num,num)
       :return: new image

       """
    iw, ih = image.size  # 原始图像的尺寸
    w, h = target_size  # 目标图像的尺寸
    scale = min(w / iw, h / ih)  # 转换的最小比例
    # 保证长或宽，至少一个符合目标图像的尺寸 0.5保证四舍五入
    nw = int(iw * scale + 0.5)
    nh = int(ih * scale + 0.5)
    image = image.resize((nw, nh), Image.BICUBIC)  # 更改图像尺寸，双立法插值
    # image.show()
    new_image = Image.new('RGB', target_size, (0, 0, 0))  # 生成黑色图像
    # // 为整数除法，计算图像的位置
    new_image.paste(image, ((w - nw) // 2, (h - nh) // 2))  # 将图像填充为中间图像，两侧为黑色的样式
    # new_image.show()
    return new_image

def get_max(x, y):
    max_x_index = np.argmax(y)
    max_x = x[max_x_index]
    max_y = y[max_x_index]
    return max_x, max_y

def my_plot(train_acc_list, dev_acc_list, losses):
    plt.figure()
    plt.plot(train_acc_list, color='r', label='train_acc')
    plt.plot(dev_acc_list, color='b', label='dev_acc')
    x = [i for i in range(len(train_acc_list))]
    for add, list_ in enumerate([train_acc_list, dev_acc_list]):
        max_x, max_y = get_max(x, list_)
        plt.text(max_x, max_y, f'{(max_x, max_y)}')
        plt.vlines(max_x, min(min(train_acc_list), min(dev_acc_list)), max_y, colors='r' if add == 0 else 'b',
                   linestyles='dashed')
        plt.hlines(max_y, 0, max_x, colors='r' if add == 0 else 'b', linestyles='dashed')
    plt.legend()

    plt.figure()
    plt.plot(losses, label='train_loss')
    plt.legend()
    y = min(losses)
    x = losses.index(y)
    plt.text(x, y, (x, round(y, 5)))
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Train Loss')
    plt.grid()
    plt.show()

