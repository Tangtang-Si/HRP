import torch
import pandas as pd
from PIL import Image
from torchvision import transforms
from torch.utils.data import Dataset
from .utils import pad_image


class RHPDataset(Dataset):
    def __init__(self,fname,max_length,tokenizer):
        img_root = './data/photo/'
        transform = transforms.Compose([transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])
        df = pd.read_excel(fname,engine='openpyxl')
        all_data = []
        all_label = []
        count = 0
        for i in range(len(df)):
            label = df['label'][i]
            comment = df['comment'][i]
            # 使用了tokenizer函数来对评论进行分词处理，分词后会生成多个输出，最常见的输出有input_ids，attention_mask，token_type_ids：这是一个整数序列，用于区分不同句子的标记。等
            bert_inputs = tokenizer(comment,padding="max_length", truncation=True, max_length = max_length)
            input_ids = torch.tensor(bert_inputs['input_ids'])
            attention_mask = torch.tensor(bert_inputs['attention_mask'])
            img_path =img_root + df['picture'][i]
            img = Image.open(img_path)
            img = pad_image(img, target_size=(224,224))
            img = transform(img)
            data = {'input_ids': input_ids,
                    'attention_mask':attention_mask,
                    'image_input':img,
                    'label':label
                    }
            all_data.append(data)
            all_label.append(label)
            count += 1
        self.__data = all_data
        self.__label = all_label


    def __getitem__(self, index):
        return self.__data[index]
        # data = self.__data[index]
        # label = self.__label[index]
        # data['label'] = label  # 将'label'键添加到数据字典中
        # return data

    def __len__(self):
        return len(self.__data)

    def getLabel(self):
        return self.__label
    

