import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
class csimdAtt(nn.Module):
    def __init__(self,input_dim,hidden_sizen,output_dim,dropout=0.5):
        super(csimdAtt, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_sizen, bidirectional=False)
        self.dropout = nn.Dropout(dropout)
        self.out = nn.Linear(hidden_sizen, output_dim)

    def attention_net(self, lstm_output, query):
        batch_size = len(lstm_output)
        hidden = query.view(batch_size, -1, 1)
        attn_weights = torch.bmm(lstm_output, hidden).squeeze(2) # attn_weights:[batch_size,seq_len,1]->attn_weights:[batch_size,seq_len]
        soft_attn_weights = F.softmax(attn_weights, 1) # soft_attn_weights :[batch_size,seq_len]
        context = torch.bmm(lstm_output.transpose(1, 2), soft_attn_weights.unsqueeze(2)).squeeze(2) # context : [batch_size, hidden_sizen]
        return context

    def forward(self, X):
        ## x : [batch_size, seq_len,embedding_dim]
        input = X
        input = input.transpose(0, 1)
        hidden_sizen = 256
        lstm_output, _ = self.lstm(input)
        lstm_output = lstm_output.transpose(0, 1)  # lstm_output : [batch_size, seq_len,hidden_sizen]
        batch_size = len(lstm_output)
        # queryc = torch.rand(1, batch_size, hidden_sizen)
        # querys = torch.rand(1, batch_size, hidden_sizen)
        queryc = torch.rand(1, batch_size, hidden_sizen).to(device)
        querys = torch.rand(1, batch_size, hidden_sizen).to(device)
        context_c = self.attention_net(lstm_output, queryc) # context : [batch_size, hidden_sizen]
        context_s = self.attention_net(lstm_output, querys)
        output_c = self.out(context_c) # out:[batch_size,output_dim]
        output_s = self.out(context_s)
        # output = output.unsqueeze(2)  # out添加一个维度到第三维，方便之后训练中的计算
        return output_c, output_s    # output [batch_size, output_dim]




#demo
# #
# lstm=csimdAtt(2,256,4)
# x=torch.Tensor([0,0,1,1,1,1,0,0]).view(2,2,2)
# out1, out2=lstm(x)
# # print('out:',out,'soft_attn_weights:',soft_attn_weights)
# print(out1)
# print(out2)

